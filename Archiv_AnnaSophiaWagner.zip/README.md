# ENDABGABE EIA2, WiSe 2020/2021



### "Firework"

Name: Anna Sophia Wagner
<br> Matrikelnummer: 263640
<br> Datum: 15.02.2021

Hiermit versichere ich, dass der abgegebene Code selbst erstellt und unter Zusammenarbeit mit meiner Kommilitonin 'Sophie Campbell' (wie auch schon die Wochenaufgaben) entstanden ist. 


