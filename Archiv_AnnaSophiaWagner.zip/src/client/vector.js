"use strict";
var Firework;
(function (Firework) {
    class Vector {
        constructor(x, y) {
            this.x = x;
            this.y = y;
        }
    }
    Firework.Vector = Vector;
})(Firework || (Firework = {}));
//# sourceMappingURL=vector.js.map